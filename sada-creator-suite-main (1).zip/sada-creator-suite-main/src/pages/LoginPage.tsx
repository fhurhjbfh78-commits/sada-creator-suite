import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '@/store/useAppStore';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isRegister, setIsRegister] = useState(false);
  const { login, register, isLoggedIn } = useAppStore();
  const navigate = useNavigate();

  if (isLoggedIn) {
    navigate('/chat');
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    if (isRegister) {
      register(email, password);
    } else {
      login(email, password);
    }
    navigate('/chat');
  };

  return (
    <div className="flex h-[100dvh] flex-col items-center justify-center gradient-bg px-6">
      <h1 className="text-6xl font-black text-foreground mb-2" style={{ fontFamily: 'Tajawal, serif' }}>صدى</h1>
      <h2 className="text-2xl font-bold text-foreground mb-10">
        {isRegister ? 'إنشاء حساب' : 'تسجيل الدخول'}
      </h2>

      <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
        <div className="glass-input flex items-center gap-3 px-4 py-3.5">
          <Mail className="w-5 h-5 text-muted-foreground" />
          <input
            type="email"
            placeholder="الايميل"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="flex-1 bg-transparent text-foreground placeholder:text-muted-foreground outline-none text-right"
            required
          />
        </div>

        <div className="glass-input flex items-center gap-3 px-4 py-3.5">
          <button type="button" onClick={() => setShowPassword(!showPassword)}>
            {showPassword ? <Eye className="w-5 h-5 text-muted-foreground" /> : <EyeOff className="w-5 h-5 text-muted-foreground" />}
          </button>
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="كلمة المرور"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="flex-1 bg-transparent text-foreground placeholder:text-muted-foreground outline-none text-right"
            required
          />
          <Lock className="w-5 h-5 text-muted-foreground" />
        </div>

        <button type="submit" className="w-full glow-btn py-3.5 text-lg animate-pulse-glow active:scale-95 transition-transform">
          {isRegister ? 'إنشاء حساب' : 'تسجيل الدخول'}
        </button>

        {/* SSO Buttons */}
        <div className="space-y-2">
          <p className="text-center text-xs text-muted-foreground">أو سجل الدخول عبر</p>
          <div className="grid grid-cols-2 gap-2">
            {[
              { name: 'Google', icon: '🔵', bg: 'bg-secondary hover:bg-secondary/80' },
              { name: 'Apple', icon: '🍎', bg: 'bg-secondary hover:bg-secondary/80' },
              { name: 'Microsoft', icon: '🟦', bg: 'bg-secondary hover:bg-secondary/80' },
              { name: 'GitHub', icon: '⚫', bg: 'bg-secondary hover:bg-secondary/80' },
            ].map(({ name, icon, bg }) => (
              <button
                key={name}
                type="button"
                onClick={() => { /* SSO placeholder - needs Cloud auth */ }}
                className={`${bg} py-2.5 rounded-xl text-sm font-bold flex items-center justify-center gap-2 active:scale-95 transition-transform`}
              >
                <span>{icon}</span>
                <span>{name}</span>
              </button>
            ))}
          </div>
        </div>

        {!isRegister && (
          <p className="text-center text-muted-foreground text-sm">نسيت كلمة المرور؟</p>
        )}

        <p className="text-center text-muted-foreground text-sm">
          {isRegister ? 'لديك حساب؟' : 'ليس لديك حساب؟'}{' '}
          <button type="button" onClick={() => setIsRegister(!isRegister)} className="text-primary underline">
            {isRegister ? 'تسجيل الدخول' : 'إنشاء حساب'}
          </button>
        </p>
      </form>
    </div>
  );
};

export default LoginPage;
